```python
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
```


```python
gdp = pd.read_csv("Data/GDP.csv")
```


```python
gdp["Country Code"].unique()
```




    array(['ABW', 'AFG', 'AGO', 'ALB', 'AND', 'ARB', 'ARE', 'ARG', 'ARM',
           'ASM', 'ATG', 'AUS', 'AUT', 'AZE', 'BDI', 'BEL', 'BEN', 'BFA',
           'BGD', 'BGR', 'BHR', 'BHS', 'BIH', 'BLR', 'BLZ', 'BMU', 'BOL',
           'BRA', 'BRB', 'BRN', 'BTN', 'BWA', 'CAF', 'CAN', 'CEB', 'CHE',
           'CHI', 'CHL', 'CHN', 'CIV', 'CMR', 'COD', 'COG', 'COL', 'COM',
           'CPV', 'CRI', 'CSS', 'CUB', 'CUW', 'CYM', 'CYP', 'CZE', 'DEU',
           'DJI', 'DMA', 'DNK', 'DOM', 'DZA', 'EAP', 'EAR', 'EAS', 'ECA',
           'ECS', 'ECU', 'EGY', 'EMU', 'ERI', 'ESP', 'EST', 'ETH', 'EUU',
           'FCS', 'FIN', 'FJI', 'FRA', 'FRO', 'FSM', 'GAB', 'GBR', 'GEO',
           'GHA', 'GIB', 'GIN', 'GMB', 'GNB', 'GNQ', 'GRC', 'GRD', 'GRL',
           'GTM', 'GUM', 'GUY', 'HIC', 'HKG', 'HND', 'HPC', 'HRV', 'HTI',
           'HUN', 'IBD', 'IBT', 'IDA', 'IDB', 'IDN', 'IDX', 'IMN', 'IND',
           'INX', 'IRL', 'IRN', 'IRQ', 'ISL', 'ISR', 'ITA', 'JAM', 'JOR',
           'JPN', 'KAZ', 'KEN', 'KGZ', 'KHM', 'KIR', 'KNA', 'KOR', 'KWT',
           'LAC', 'LAO', 'LBN', 'LBR', 'LBY', 'LCA', 'LCN', 'LDC', 'LIC',
           'LIE', 'LKA', 'LMC', 'LMY', 'LSO', 'LTE', 'LTU', 'LUX', 'LVA',
           'MAC', 'MAF', 'MAR', 'MCO', 'MDA', 'MDG', 'MDV', 'MEA', 'MEX',
           'MHL', 'MIC', 'MKD', 'MLI', 'MLT', 'MMR', 'MNA', 'MNE', 'MNG',
           'MNP', 'MOZ', 'MRT', 'MUS', 'MWI', 'MYS', 'NAC', 'NAM', 'NCL',
           'NER', 'NGA', 'NIC', 'NLD', 'NOR', 'NPL', 'NRU', 'NZL', 'OED',
           'OMN', 'OSS', 'PAK', 'PAN', 'PER', 'PHL', 'PLW', 'PNG', 'POL',
           'PRE', 'PRI', 'PRK', 'PRT', 'PRY', 'PSE', 'PSS', 'PST', 'PYF',
           'QAT', 'ROU', 'RUS', 'RWA', 'SAS', 'SAU', 'SDN', 'SEN', 'SGP',
           'SLB', 'SLE', 'SLV', 'SMR', 'SOM', 'SRB', 'SSA', 'SSD', 'SSF',
           'SST', 'STP', 'SUR', 'SVK', 'SVN', 'SWE', 'SWZ', 'SXM', 'SYC',
           'SYR', 'TCA', 'TCD', 'TEA', 'TEC', 'TGO', 'THA', 'TJK', 'TKM',
           'TLA', 'TLS', 'TMN', 'TON', 'TSA', 'TSS', 'TTO', 'TUN', 'TUR',
           'TUV', 'TZA', 'UGA', 'UKR', 'UMC', 'URY', 'USA', 'UZB', 'VCT',
           'VEN', 'VGB', 'VIR', 'VNM', 'VUT', 'WLD', 'WSM', 'XKX', 'YEM',
           'ZAF', 'ZMB', 'ZWE'], dtype=object)




```python
pakgdp = gdp.loc[gdp["Country Code"] == "PAK"]
```


```python
yrs = pakgdp.columns.values[4:].astype(int)
```


```python
pakgdps = pakgdp.values[0][4:]
```


```python
plt.figure(figsize=(10,5))
plt.plot(yrs, pakgdps)
```




    [<matplotlib.lines.Line2D at 0x2205efd9048>]




![png](output_6_1.png)



```python
gdpgrowth = pd.read_csv("Data/GDPgrowth.csv")
```


```python
pakgdpgrowth = gdpgrowth.loc[gdpgrowth["Country Code"] == "PAK"]
```


```python
pakgdpgrowth = pakgdpgrowth.values[0][4:]
```


```python
plt.figure(figsize=(10,5))
plt.plot(yrs, pakgdpgrowth)
```




    [<matplotlib.lines.Line2D at 0x224c5237d68>]




![png](output_10_1.png)



```python
pop = pd.read_csv("Data/Population.csv")
```


```python
pakpop = pop.loc[pop["Country Code"] == "PAK"]
```


```python
pakpop = pakpop.values[0][4:]
```


```python
plt.figure(figsize=(10,5))
plt.plot(yrs, pakpop)
```




    [<matplotlib.lines.Line2D at 0x2205f089780>]




![png](output_14_1.png)



```python
plt.figure(figsize=(10,5))
plt.plot(pakpop,pakgdps)
```




    [<matplotlib.lines.Line2D at 0x2205f0f3b00>]




![png](output_15_1.png)



```python
chngdp = gdp.loc[gdp["Country Code"] == "CHN"].values[0][4:]
```


```python
chnpop = pop.loc[pop["Country Code"] == "CHN"].values[0][4:]
```


```python
indgdps = gdp.loc[gdp["Country Code"] == "IND"].values[0][4:]
```


```python
indpop = pop.loc[pop["Country Code"] == "IND"].values[0][4:]
```


```python
ukgdps = gdp.loc[gdp["Country Code"] == "GBR"].values[0][4:]
```


```python
jpgdps = gdp.loc[gdp["Country Code"] == "JPN"].values[0][4:]
```


```python
irngdps = gdp.loc[gdp["Country Code"] == "IRN"].values[0][4:]
```


```python
plt.figure(figsize=(20,10))

plt.subplot(2,2,1)
plt.plot(yrs,pakpop)
plt.title("Pak pop")

plt.subplot(2,2,2)
plt.plot(yrs,pakgdps)
plt.title("Pakistan GDP")
```




    Text(0.5, 1.0, 'Pakistan GDP')




![png](output_23_1.png)



```python
plt.figure(figsize=(20,10))

plt.subplot(2,2,1)
plt.plot(yrs,chnpop)
plt.title("Chn pop")

plt.subplot(2,2,2)
plt.plot(yrs,chngdp)
plt.title("Chn GDP")
```




    Text(0.5, 1.0, 'Chn GDP')




![png](output_24_1.png)



```python
plt.figure(figsize=(20,10))

plt.subplot(2,2,1)
plt.plot(yrs,indpop)
plt.title("India pop")

plt.subplot(2,2,2)
plt.plot(yrs,indgdps)
plt.title("India GDP")
```




    Text(0.5, 1.0, 'India GDP')




![png](output_25_1.png)



```python

```


```python

```
